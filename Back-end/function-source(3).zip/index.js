const { MongoClient } = require('mongodb');

// MongoDB Atlas connection URI
const uri = 'mongodb+srv://admin:SeFMpKGL9P3RhAQX@cluster0.sjck0va.mongodb.net/test?retryWrites=true&w=majority';

exports.getUserPassword = async (req, res) => {
    try {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        const collection = client.db("eduHubDB").collection("users");

        // Extract username and email from request body
        const { username, email } = req.body;

        // Find user by username and email in the database
        const user = await collection.findOne({ username, email });

        // Close the database connection
        await client.close();

        // Set CORS headers
        res.set('Access-Control-Allow-Origin', '*'); // Allow requests from any origin
        res.set('Access-Control-Allow-Methods', 'GET, POST'); // Allow only GET and POST requests
        res.set('Access-Control-Allow-Headers', 'Content-Type'); // Allow the Content-Type header

        if (user) {
            res.status(200).json({ password: user.password });
        } else {
            res.status(404).send('User not found');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
};
