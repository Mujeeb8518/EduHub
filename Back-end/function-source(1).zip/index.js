const { MongoClient } = require('mongodb');

// MongoDB Atlas connection URI
const uri = 'mongodb+srv://admin:SeFMpKGL9P3RhAQX@cluster0.sjck0va.mongodb.net/test?retryWrites=true&w=majority';

exports.registerUser = async (req, res) => {
    try {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        const collection = client.db("eduHubDB").collection("users");

        // Extract user data from request body
        const userData = req.body;

        // Insert the user data into the database
        const result = await collection.insertOne(userData);

        // Close the database connection
        await client.close();

        // Set CORS headers
        res.set('Access-Control-Allow-Origin', '*'); // Allow requests from any origin
        res.set('Access-Control-Allow-Methods', 'GET, POST'); // Allow only GET and POST requests
        res.set('Access-Control-Allow-Headers', 'Content-Type'); // Allow the Content-Type header

        // Respond with success message
        res.status(201).send(`User registered successfully with ID: ${result.insertedId}`);
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
};
