const { MongoClient } = require('mongodb');

// MongoDB Atlas connection URI
const uri = 'mongodb+srv://admin:SeFMpKGL9P3RhAQX@cluster0.sjck0va.mongodb.net/test?retryWrites=true&w=majority';

exports.getPostsAndSolutions = async (req, res) => {
    if (req.method === 'OPTIONS') {
        // Handle CORS preflight requests
        res.set('Access-Control-Allow-Methods', 'GET');
        res.set('Access-Control-Allow-Headers', 'Content-Type');
        res.set('Access-Control-Allow-Origin', '*');
        res.status(204).send('');
    } else {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        try {
            await client.connect();
            const db = client.db("eduHubDB");
            const postsCollection = db.collection("posts");
            const solutionsCollection = db.collection("solutions");

            // Fetch and sort posts and solutions by createdAt
            const posts = await postsCollection.find({}).sort({ createdAt: 1 }).toArray();
            const solutions = await solutionsCollection.find({}).sort({ createdAt: 1 }).toArray();

            let results = [];
            // Assuming the number of posts and solutions are the same or solutions are fewer
            const maxLength = Math.max(posts.length, solutions.length);
            for (let i = 0; i < maxLength; i++) {
                if (posts[i]) results.push(posts[i]); // Add post
                if (solutions[i]) results.push(solutions[i]); // Then add solution
            }

            res.set('Access-Control-Allow-Origin', '*');
            res.status(200).json(results);
        } catch (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } finally {
            await client.close();
        }
    }
};
