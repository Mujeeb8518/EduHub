const { MongoClient } = require('mongodb');
const jwt = require('jsonwebtoken');

// MongoDB Atlas connection URI
const uri = 'mongodb+srv://admin:SeFMpKGL9P3RhAQX@cluster0.sjck0va.mongodb.net/test?retryWrites=true&w=majority';

// Secret for JWT signing; should be more secure and not hard-coded in production
const jwtSecret = 'key';

exports.loginUser = async (req, res) => {
        // Directly set CORS headers using setHeader
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

        // Handle OPTIONS request for CORS preflight
        if (req.method === 'OPTIONS') {
            res.status(204).send('');
            return;
        }
    try {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        const collection = client.db("eduHubDB").collection("users");

        const { username, password } = req.body;
        const user = await collection.findOne({ username, password });
        await client.close();

        // Set CORS headers
        res.set('Access-Control-Allow-Origin', '*'); // Allow requests from any origin
        res.set('Access-Control-Allow-Methods', 'GET, POST'); // Allow only GET and POST requests
        res.set('Access-Control-Allow-Headers', 'Content-Type'); // Allow the Content-Type header

        if (user) {
            // Generate a JWT for the user
            const token = jwt.sign({ username: user.username }, jwtSecret, { expiresIn: '1h' });
            res.status(200).json({ message: 'Login successful', token: token });
        } else {
            res.status(401).send('Invalid username or password');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
};


