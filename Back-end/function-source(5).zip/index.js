const { MongoClient } = require('mongodb');

// MongoDB Atlas connection URI
const uri = 'mongodb+srv://admin:SeFMpKGL9P3RhAQX@cluster0.sjck0va.mongodb.net/test?retryWrites=true&w=majority';

exports.getPosts = async (req, res) => {
    // Set CORS headers for the preflight request
    if (req.method === 'OPTIONS') {
        res.set('Access-Control-Allow-Methods', 'GET');
        res.set('Access-Control-Allow-Headers', 'Content-Type');
        res.set('Access-Control-Allow-Origin', '*');
        res.status(204).send('');
    } else {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        try {
            await client.connect();
            const collection = client.db("eduHubDB").collection("posts");

            // Fetch all posts. Adjust query as needed.
            const posts = await collection.find({}).toArray();

            res.set('Access-Control-Allow-Origin', '*');
            res.status(200).json(posts);
        } catch (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } finally {
            await client.close();
        }
    }
};
