const { MongoClient } = require('mongodb');
const jwt = require('jsonwebtoken');

// MongoDB Atlas connection URI and JWT Secret
const uri = 'mongodb+srv://admin:SeFMpKGL9P3RhAQX@cluster0.sjck0va.mongodb.net/test?retryWrites=true&w=majority';
const jwtSecret = 'key';

exports.addPost = async (req, res) => {
    // Directly set CORS headers using setHeader
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    // Handle OPTIONS request for CORS preflight
    if (req.method === 'OPTIONS') {
        res.status(204).send('');
        return;
    }

    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1]; // Extract the token

    if (!token) {
        res.status(401).send('Authorization header not found.');
        return;
    }

    try {
        // Verify JWT
        const decoded = jwt.verify(token, jwtSecret);

        // Connect to MongoDB
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        const collection = client.db("eduHubDB").collection("posts");

        const { postContent } = req.body;

        await collection.insertOne({ username: decoded.username, postContent, createdAt: new Date() });
        await client.close();

        res.status(200).send('Post added successfully');
    } catch (err) {
        console.error(err);

        if (err.name === 'JsonWebTokenError') {
            res.status(403).send('Invalid token.');
        } else {
            res.status(500).send('Internal Server Error');
        }
    }
};
